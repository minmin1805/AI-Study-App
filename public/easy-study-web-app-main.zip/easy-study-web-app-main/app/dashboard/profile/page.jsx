"use client"
import { UserProfile } from '@clerk/nextjs'
import React from 'react'

function Profile() {
  return (
    <div>
        <UserProfile/>
    </div>
  )
}

export default Profile